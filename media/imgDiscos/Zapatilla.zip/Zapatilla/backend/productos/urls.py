from django.urls import path
from . import views

urlpatterns = [
    path('zapatillas/', views.index, name='index'),
    path('zapatillas/<int:id>/', views.detalle, name='detalle'),
    path('api/zapatilla/', views.lista_zapatilla, name='lista_zapatilla'),
]


# este es tu url si se pero es que le profe esta modificando las url de los demas el conta y eso pero a mi no me salen sus url correspondientes
# se crea el archivo manuial, cuando tu creas otra aplicaion como remu y conta no trae el url.py
# almenos en el video del profe paso esto