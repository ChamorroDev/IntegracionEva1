from django.contrib import admin
from .models import Zapatilla

admin.site.register(Zapatilla)

# Register your models here.
