from django.shortcuts import render, get_object_or_404
from .models import Zapatilla

def index(request):
    zapatillas = Zapatilla.objects.all()
    return render(request, 'productos/index.html', {'zapatillas': zapatillas})

def detalle(request, id):
    zapatilla = get_object_or_404(Zapatilla, id=id)
    return render(request, 'productos/detalle.html', {'zapatilla': zapatilla})

def lista_zapatilla(request):
    zapatilla = Zapatilla.objects.all().values('id', 'nombre', 'color')
    return JsonResponse(list(zapatilla), safe=False)
# Create your views here.
